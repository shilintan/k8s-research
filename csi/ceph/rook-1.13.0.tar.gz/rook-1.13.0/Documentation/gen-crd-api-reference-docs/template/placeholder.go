// Placeholder file to make Go vendor this directory properly.
package template
