See the [Operator Helm Chart](/Documentation/Helm-Charts/operator-chart.md) documentation.
